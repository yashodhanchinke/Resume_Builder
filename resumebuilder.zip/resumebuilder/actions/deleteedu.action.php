<?php

require '../asset/class/database.class.php';
require '../asset/class/function.class.php';

if($_GET){
  $post=$_GET;

// echo "<pre>";
// print_r($post);
// die();
if($post['id']&& $post['resume_id'] )
{
    
    try{
         $query = "DELETE FROM educations WHERE id={$post['id']} AND resume_id={$post['resume_id']}";
       
        
        $db->query($query);
       
        $fn->setAlert('education deleted !');
        $fn->redirect('../updateresume.php?resume='.$post['slug']);



    }catch(Exception $error){
      $fn->setError('education is not deleted!');
      $fn->redirect('../updateresume.php?resume='.$post['slug']);
    }
}

else{
  $fn->setError('please fill the form');
  $fn->redirect('../updateresume.php?resume='.$post['slug']);
}

}
else{
    $fn->redirect('../updateresume.php?resume='.$post['slug']);
}